﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class Level : MonoBehaviour {
public Button BmulaiMain;
public Button BPetunjuk;
public Button BBack;
public Button BLevel1;
public Button BLevel2;
public Button BPenjumlahan;
public Button BPengurangan;
public Button BPerkalian;
public Button BPembagian;

	// Use this for initialization
	// Update is called once per frame
	    void Start()
        {
				
			
            
        }
       
        public void StartGame(string level)
        {
            Application.LoadLevel(level);
        }

	public void mulaiMainOnClick()
    { 	
		SceneManager.LoadScene("Level");
    }
	
	void PetunjukOnClick()
    {
			//	PetunjukButton.onClick.AddListener(delegate() { StartGame("Petunjuk"); });
			BPetunjuk.onClick.AddListener(delegate() { StartGame("Petunjuk"); });
        SceneManager.LoadScene("Petunjuk");
    }
	public void BackOnClick()
    {
		//		BackButton.onClick.AddListener(delegate() { StartGame("Dashboard"); });	
			
        SceneManager.LoadScene("Dashboard");
    }
	public void BackToLevelOnClick()
    {
		//		BackButton.onClick.AddListener(delegate() { StartGame("Dashboard"); });	
			
        SceneManager.LoadScene("Level");
    }
	//Parent and Child Level 1
	public void GoToLevel1OnClick()
    {
		//		BackButton.onClick.AddListener(delegate() { StartGame("Dashboard"); });	
			
        SceneManager.LoadScene("Level1");
    }
	public void GoToLevel1_Soal1OnClick()
    {
		//		BackButton.onClick.AddListener(delegate() { StartGame("Dashboard"); });	
			
        SceneManager.LoadScene("Level1_Penjumlahan_1");
    }
	// EOF
	
	
	public void GoToLevel2OnClick()
    {
		//		BackButton.onClick.AddListener(delegate() { StartGame("Dashboard"); });	
			
        SceneManager.LoadScene("Level2");
    }
	
	public void GoToPenjumlahanOnClick()
    {
		//		BackButton.onClick.AddListener(delegate() { StartGame("Dashboard"); });		
        SceneManager.LoadScene("Level1_Penjumlahan");
    }
	
	
	public void GoToPenguranganOnClick()
    {
		//		BackButton.onClick.AddListener(delegate() { StartGame("Dashboard"); });	
        SceneManager.LoadScene("Level1_Pengurangan");
    }
	
	public void GoToPerkalianOnClick()
    {
		//		BackButton.onClick.AddListener(delegate() { StartGame("Dashboard"); });	
        SceneManager.LoadScene("Level2_Perkalian");
    }
	
	public void GoToPembagianOnClick()
    {
		//		BackButton.onClick.AddListener(delegate() { StartGame("Dashboard"); });	
        SceneManager.LoadScene("Level2_Pembagian");
    }
	//Level 1 dan child
	public void BackToLevel1OnClick()
    {
		//		BackButton.onClick.AddListener(delegate() { StartGame("Dashboard"); });	
        SceneManager.LoadScene("Level1");
    }
	
	public void BackToLevel2OnClick()
    {
		//		BackButton.onClick.AddListener(delegate() { StartGame("Dashboard"); });	
        SceneManager.LoadScene("Level2");
    }
	
	
}
