﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class Dashboard : MonoBehaviour {
public Button BmulaiMain;
public Button BPetunjuk;
public Button BBack;
public Text Highscore;
	// Use this for initialization
	// Update is called once per frame
	public int CURRENT_SCORE = 0;
	    void Start()
        {
			Highscore = gameObject.GetComponent<Text>();
			Highscore.text="High Score : "+CURRENT_SCORE;
		//		Button BmulaiMain = gameObject.GetComponent<Button>();
			//		BmulaiMain.onClick.AddListener(delegate() { StartGame("Level"); });
			  //  Button BPetunjuk = gameObject.GetComponent<Button>();
				//	BPetunjuk.onClick.AddListener(delegate() { StartGame("Petunjuk"); });
				
			
            
        }
		void Update(){
	//		Highscore.text="High";
		}
       
        void StartGame(string level)
        {
            Application.LoadLevel(level);
        }

	public void mulaiMainOnClick()
    {
      	
		SceneManager.LoadScene("Level");
    }
	
	public void PetunjukOnClick()
    {
			//	PetunjukButton.onClick.AddListener(delegate() { StartGame("Petunjuk"); });
		SceneManager.LoadScene("Petunjuk");
    }
	public void BackOnClick()
    {
		//		BackButton.onClick.AddListener(delegate() { StartGame("Dashboard"); });	
			
        SceneManager.LoadScene("Dashboard");
    }
}
