﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class LevelPenjumlahan_Soal1 : MonoBehaviour {
public Button BBack;
public Button BJawab;

	    void Start()
        {
		
            
        }
       
        public void StartGame(string level)
        {
            Application.LoadLevel(level);
        }

	public void mulaiMainOnClick()
    { 	
		SceneManager.LoadScene("Level");
    }
	
	
	public void BackOnClick()
    {
		//		BackButton.onClick.AddListener(delegate() { StartGame("Dashboard"); });	
			
        SceneManager.LoadScene("Level1_Penjumlahan");
    }
	
	
	
	
	
}
