﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class gameController : MonoBehaviour {

	GameObject heart1, heart2, heart3, heart4, heart5;
	GameObject popup_kategori, popup_menu;
	public static int JUMLAH_HEART = 5;

	// Use this for initialization
	void Start () {
		popup_kategori = GameObject.Find ("popup_kategori");
		popup_kategori.gameObject.SetActive (false);
		popup_menu = GameObject.Find ("popup_menu");
		popup_menu.gameObject.SetActive (false);

		heart1 = GameObject.Find ("heart1");
		heart2 = GameObject.Find ("heart2");
		heart3 = GameObject.Find ("heart3");
		heart4 = GameObject.Find ("heart4");
		heart5 = GameObject.Find ("heart5");

		heart1.gameObject.SetActive (true);
		heart2.gameObject.SetActive (true);
		heart3.gameObject.SetActive (true);
		heart4.gameObject.SetActive (true);
		heart5.gameObject.SetActive (true);
	}
	
	// Update is called once per frame
	void Update () {

		if (JUMLAH_HEART > 5)
			JUMLAH_HEART = 5;

		switch (JUMLAH_HEART) {
		case 5:
			heart1.gameObject.SetActive (true);
			heart2.gameObject.SetActive (true);
			heart3.gameObject.SetActive (true);
			heart4.gameObject.SetActive (true);
			heart5.gameObject.SetActive (true);
			break;
		case 4:
			heart1.gameObject.SetActive (true);
			heart2.gameObject.SetActive (true);
			heart3.gameObject.SetActive (true);
			heart4.gameObject.SetActive (true);
			heart5.gameObject.SetActive (false);
			break;
		case 3:
			heart1.gameObject.SetActive (true);
			heart2.gameObject.SetActive (true);
			heart3.gameObject.SetActive (true);
			heart4.gameObject.SetActive (false);
			heart5.gameObject.SetActive (false);
			break;
		case 2:
			heart1.gameObject.SetActive (true);
			heart2.gameObject.SetActive (true);
			heart3.gameObject.SetActive (false);
			heart4.gameObject.SetActive (false);
			heart5.gameObject.SetActive (false);
			break;
		case 1:
			heart1.gameObject.SetActive (true);
			heart2.gameObject.SetActive (false);
			heart3.gameObject.SetActive (false);
			heart4.gameObject.SetActive (false);
			heart5.gameObject.SetActive (false);
			break;
		case 0:
			heart1.gameObject.SetActive (false);
			heart2.gameObject.SetActive (false);
			heart3.gameObject.SetActive (false);
			heart4.gameObject.SetActive (false);
			heart5.gameObject.SetActive (false);
			break;
		}
	}

	public void StartGame(){
		popup_kategori.gameObject.SetActive (true);
	}

	public void ChooseCategory(){
		if (popup_menu.activeSelf | popup_kategori.activeSelf) {
			popup_menu.gameObject.SetActive (false);
			popup_kategori.gameObject.SetActive (false);
		}
		popup_kategori.gameObject.SetActive (true);
	}

	public void ChooseMainMenu(){
		if (popup_menu.activeSelf | popup_kategori.activeSelf) {
			popup_menu.gameObject.SetActive (false);
			popup_kategori.gameObject.SetActive (false);
		}
		popup_menu.gameObject.SetActive (true);
	}

	public void ClosePopup(){
		popup_kategori.gameObject.SetActive (false);
		popup_menu.gameObject.SetActive (false);
	}

	public void GoToHome(){
		SceneManager.LoadScene("main_menu");
	}

	public void GoToKatPenjumlahan(){
		SceneManager.LoadScene("kat_penjumlahan");
	}

	public void GoToKatPengurangan(){
		SceneManager.LoadScene("kat_pengurangan");
	}

	public void GoToKatPerkalian(){
		SceneManager.LoadScene("kat_perkalian");
	}

	public void GoToKatPembagian(){
		SceneManager.LoadScene("kat_pembagian");
	}

	public void GoExit(){
		Application.Quit ();
	}
}
