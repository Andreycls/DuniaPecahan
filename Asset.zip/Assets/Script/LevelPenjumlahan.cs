﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
//using UnityEngine.GameObject;

public class LevelPenjumlahan : MonoBehaviour {
public Button BmulaiMain;
public Button BPetunjuk;
public Button BBack;
public Button BLevel1;
public Button BLevel2;
public Button BPenjumlahan;
public Button BPengurangan;
public Button BPerkalian;
public Button BPembagian;
public GameObject PlusStar_1;
public GameObject PlusStar_2;
public GameObject PlusStar_3;
public GameObject PlusStar_4;
public GameObject PlusStar_5;

	// Use this for initialization
	// Update is called once per frame
	    void Start()
        {
		PlusStar_1.SetActive(true);
		PlusStar_2.SetActive(false);
		PlusStar_3.SetActive(false);
		PlusStar_4.SetActive(false);
		PlusStar_5.SetActive(false);		
		
            
        }
       
        public void StartGame(string level)
        {
            Application.LoadLevel(level);
        }

	public void mulaiMainOnClick()
    { 	
		SceneManager.LoadScene("Level");
    }
	
	void PetunjukOnClick()
    {
			//	PetunjukButton.onClick.AddListener(delegate() { StartGame("Petunjuk"); });
			BPetunjuk.onClick.AddListener(delegate() { StartGame("Petunjuk"); });
        SceneManager.LoadScene("Petunjuk");
    }
	public void BackOnClick()
    {
		//		BackButton.onClick.AddListener(delegate() { StartGame("Dashboard"); });	
			
        SceneManager.LoadScene("Dashboard");
    }
	public void BackToLevelOnClick()
    {
		//		BackButton.onClick.AddListener(delegate() { StartGame("Dashboard"); });	
			
        SceneManager.LoadScene("Level");
    }
	// Level 1 Parent and child
	public void GoToSoal1OnClick()
    {
		//		BackButton.onClick.AddListener(delegate() { StartGame("Dashboard"); });	
			
        SceneManager.LoadScene("Level1_Penjumlahan_1");
    }
	
	
	public void GoToLevel2OnClick()
    {
		//		BackButton.onClick.AddListener(delegate() { StartGame("Dashboard"); });	
			
        SceneManager.LoadScene("Level2");
    }
	
	public void GoToPenjumlahanOnClick()
    {
		//		BackButton.onClick.AddListener(delegate() { StartGame("Dashboard"); });		
        SceneManager.LoadScene("Level1_Penjumlahan");
    }
	
	
	public void GoToPenguranganOnClick()
    {
		//		BackButton.onClick.AddListener(delegate() { StartGame("Dashboard"); });	
        SceneManager.LoadScene("Level1_Pengurangan");
    }
	
	public void GoToPerkalianOnClick()
    {
		//		BackButton.onClick.AddListener(delegate() { StartGame("Dashboard"); });	
        SceneManager.LoadScene("Level2_Perkalian");
    }
	
	public void GoToPembagianOnClick()
    {
		//		BackButton.onClick.AddListener(delegate() { StartGame("Dashboard"); });	
        SceneManager.LoadScene("Level2_Pembagian");
    }
	
	public void BackToLevel1OnClick()
    {
		//		BackButton.onClick.AddListener(delegate() { StartGame("Dashboard"); });	
        SceneManager.LoadScene("Level1");
    }
	
	public void BackToLevel2OnClick()
    {
		//		BackButton.onClick.AddListener(delegate() { StartGame("Dashboard"); });	
        SceneManager.LoadScene("Level2");
    }
	
	
}
